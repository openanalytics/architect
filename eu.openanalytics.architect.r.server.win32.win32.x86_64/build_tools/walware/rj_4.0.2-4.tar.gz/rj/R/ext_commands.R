 #=============================================================================#
 # Copyright (c) 2010, 2019 Stephan Wahlbrink and others.
 # 
 # This program and the accompanying materials are made available under the
 # terms of the Eclipse Public License 2.0 which is available at
 # https://www.eclipse.org/legal/epl-2.0, or the Apache License, Version 2.0
 # which is available at https://www.apache.org/licenses/LICENSE-2.0.
 # 
 # SPDX-License-Identifier: EPL-2.0 OR Apache-2.0
 # 
 # Contributors:
 #     Stephan Wahlbrink <sw@wahlbrink.eu> - initial API and implementation
 #=============================================================================#


## RJ Client (UI)

#' Sends an custom command to the client which executes the command
#' if it is supported ("ext client command")
#' 
#' @param commandId the id of the command
#' @param args an optional list with arguments (meaning depends on command)
#' @param wait if R must wait until the command is executed
#'     (necessary if you need a return value)
#' @returnType char
.client.execCommand <- function(commandId, args= list(), wait= TRUE) {
	if (missing(commandId)) {
		stop("Missing param: commandId");
	}
	if (!is.list(args)) {
		stop("Illegal argument: args must be a list");
	}
	if (length(args) > 0) {
		args.names <- names(args);
		if (is.null(args.names) || any(is.na(args.names))) {
			stop("Illegal argument: args must be named");
		}
	}
	
	options <- 0L;
	if (wait) {
		options <- options + 1L;
	}
	.Call("Re_ExecJCommand", paste("ext", commandId, sep= ":"), args, options,
						PACKAGE= "(embedding)" );
}

