 #=============================================================================#
 # Copyright (c) 2009, 2019 Stephan Wahlbrink and others.
 # 
 # This program and the accompanying materials are made available under the
 # terms of the Eclipse Public License 2.0 which is available at
 # https://www.eclipse.org/legal/epl-2.0, or the Apache License, Version 2.0
 # which is available at https://www.apache.org/licenses/LICENSE-2.0.
 # 
 # SPDX-License-Identifier: EPL-2.0 OR Apache-2.0
 # 
 # Contributors:
 #     Stephan Wahlbrink <sw@wahlbrink.eu> - initial API and implementation
 #=============================================================================#


## R IDE

#' Opens a file in an editor in StatET
#' @param filename name of file to open
#' 
#' @export
openInEditor <- function(name, fileName, elementName, filename) {
	if (!missing(filename)) {
		fileName <- filename
	}
	if (missing(name) && missing(fileName) && missing(elementName)) {
		stop("Missing argument: name")
	}
	if (missing(fileName) && missing(elementName)) {
		# auto
		fileName <- NULL
		elementName <- NULL
		if (is.character(name) && length(name) == 1) {
			fileName <- name
		}
		else {
			elementName <- substitute(name)
		}
	}
	else if (!missing(elementName)) {
		fileName <- NULL
		elementName # test, if it refers to an existing element
		elementName <- substitute(elementName)
	}
	else if (!missing(fileName)) {
		elementName <- NULL
	}
	
	if (!is.null(fileName)) {
		if (!is.character(fileName) || length(fileName) != 1) {
			stop("Illegal argument: fileName")
		}
		.client.execCommand("common/showFile", list(
						filename= fileName ), wait= TRUE)
	}
	else {
		elementName <- deparse(elementName, backtick= TRUE, control= c(),
				width.cutoff= 500, nlines= 2L)
		if (length(elementName) != 1) {
			stop("Illegal argument: elementName")
		}
		.client.execCommand("showElement", list(
						elementName= elementName ), wait= TRUE)
	}
	return (invisible())
}

#' Opens the package manager in StatET
#' 
#' @export
openPackageManager <- function() {
	.client.execCommand("r/openPackageManager", wait= FALSE)
	return (invisible())
}

#' Asks the user to choose a file using the StatET GUI.
#' 
#' @param new if the choosen file can be new (does not yet exits)
#' @export
statet.chooseFile <- function(new= FALSE) {
	if (!is.logical(new) || length(new) != 1) {
		stop("Illegal argument: new")
	}
	answer <- .client.execCommand("common/chooseFile", list(
					newResource= new ), wait= TRUE)
	if (is.null(answer)) { # operation cancelled
		return (invisible())
	}
	return (answer$filename)
}

#' Shows the Cmd History view in StatET
#' 
#' @export
statet.showHistory <- function() {
	.client.execCommand("common/showHistory", wait= FALSE)
	return (invisible())
}


#' Initializes extensions for StatET IDE
#' 
#' @param mode debug mode
#' @param ext enable extensions for better debugging experience
#' 
#' @export
.statet.initDebug <- function(mode= FALSE, ext= TRUE, ...) {
	if (mode) {
		dbg.init(...);
	}
	if (options("keep.source") != TRUE) {
		options("keep.source"= TRUE)
	}
	if (ext) {
		dbg.initSrcExt();
	}
}

#' Configures R help for StatET IDE
#' 
#' @export
.statet.initHelp <- function(...) {
	statet.reassignHelp(...);
}
