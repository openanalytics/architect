 #=============================================================================#
 # Copyright (c) 2018, 2019 Stephan Wahlbrink and others.
 # 
 # This program and the accompanying materials are made available under the
 # terms of the Eclipse Public License 2.0 which is available at
 # https://www.eclipse.org/legal/epl-2.0, or the Apache License, Version 2.0
 # which is available at https://www.apache.org/licenses/LICENSE-2.0.
 # 
 # SPDX-License-Identifier: EPL-2.0 OR Apache-2.0
 # 
 # Contributors:
 #     Stephan Wahlbrink <sw@wahlbrink.eu> - initial API and implementation
 #=============================================================================#


## RJ graphics

.rj.initGD <- function(default= TRUE, ...) {
	if (length(find.package("rj.gd", quiet=TRUE, verbose=FALSE)) == 0) {
		warning("The graphics device for RJ is not available: R package 'rj.gd' not found.");
		return (FALSE);
	}
	rj.gd:::.rj.getGDVersion();
	if (default) {
		options(device=rj::rj.GD);
	}
	return (TRUE);
}

rj.GD <- function(name= "rj.gd", width= 7, height= 7, size.unit= "in",
		xpinch= NA, ypinch= NA, canvas= "white",
		pointsize= 12, gamma= 1.0, ...) {
	rj.gd::rj.GD(name= name, width= width, height= height, size.unit= size.unit,
			xpinch= xpinch, ypinch= ypinch, canvas= canvas,
			pointsize= pointsize, gamma= gamma, ... );
}


#' Copies an R graphic from specified device to a new device.
gr.copyGraphic <- function(devNr= dev.cur(), device= pdf, ...) {
	prevDevNr <- dev.cur();
	on.exit(dev.set(prevDevNr));
	dev.set(devNr);
	din <- par("din");
	dev.copy(device, width= din[1], height= din[2], ...);
	dev.off();
	invisible(devNr);
}


## RJ graphics (intern only)

gr.convertUser2Dev <- function(xy, devId) {
	currentDevId <- dev.cur()
	if (devId != currentDevId) {
		on.exit(expr= dev.set(which= currentDevId), add= TRUE)
		dev.set(which= devId)
	}
	xy[1] <- grconvertX(xy[1], from= "user", to= "dev")
	xy[2] <- grconvertY(xy[2], from= "user", to= "dev")
	return (xy)
}

gr.convertDev2User <- function(xy, devId) {
	currentDevId <- dev.cur()
	if (devId != currentDevId) {
		on.exit(expr= dev.set(which= currentDevId), add= TRUE)
		dev.set(which= devId)
	}
	xy[1] <- grconvertX(xy[1], from= "dev", to= "user")
	xy[2] <- grconvertY(xy[2], from= "dev", to= "user")
	return (xy)
}

