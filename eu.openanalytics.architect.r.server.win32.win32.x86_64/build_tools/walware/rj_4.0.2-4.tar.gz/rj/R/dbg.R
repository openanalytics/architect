 #=============================================================================#
 # Copyright (c) 2011, 2019 Stephan Wahlbrink and others.
 # 
 # This program and the accompanying materials are made available under the
 # terms of the Eclipse Public License 2.0 which is available at
 # https://www.eclipse.org/legal/epl-2.0, or the Apache License, Version 2.0
 # which is available at https://www.apache.org/licenses/LICENSE-2.0.
 # 
 # SPDX-License-Identifier: EPL-2.0 OR Apache-2.0
 # 
 # Contributors:
 #     Stephan Wahlbrink <sw@wahlbrink.eu> - initial API and implementation
 #=============================================================================#


## RJ dbg


dbg.vars <- new.env();
dbg.vars$isAppExtInitialized <- FALSE;

#' Initializes the debug tools
dbg.init <- function(...) {
	compiler::enableJIT(level= 0L);
	
	if (!dbg.vars$isAppExtInitialized) {
		dbg.vars$isAppExtInitialized <- TRUE;
		apps.initDbgExt();
	}
	
	return (invisible());
}


# SrcExt

dbg.vars$isSrcExtInitialized <- FALSE
dbg.initSrcExt <- function() {
	if (dbg.vars$isSrcExtInitialized) {
		return (invisible());
	}
	dbg.vars$isSrcExtInitialized <- TRUE;
	
	baseEnv <- as.environment("package:base");
	
	# ext base::srcfile
	injectSrcfile <- function(fname, envir) {
		ffun <- get(fname, envir= envir);
		fbody <- body(ffun);
		l <- length(fbody);
		
		if (length(fbody[[l]]) == 2 && fbody[[l]][[1]] == "return") {
			c1 <- quote(rj:::.statet.extSrcfile(x));
			c1[[2]] <- fbody[[l]][[2]];
			fbody[[l]][[2]] <- c1;
			body(ffun) <- fbody;
			return (patchPackage(fname, ffun, envir= envir));
		}
		else {
			cat("Could not install rj extension 'extSrcfile' for '", fname, "'.\n", sep= "");
			return (FALSE);
		}
	}
	injectSource <- function(fname, envir) {
		ffun <- get(fname, envir= envir);
		fbody <- body(ffun);
		l <- length(fbody);
		changed <- FALSE;
		
		idx <- .searchExpr(fbody, function(expr) {
					return (length(expr) == 3 && expr[[1]] == "<-"
							&& expr[[2]] == "exprs");
				});
		if (!is.null(idx)) {
			c1 <- quote(rj:::.statet.extSource(x));
			c1[[2]] <- fbody[[idx]][[3]];
			fbody[[idx]][[3]] <- c1;
			changed <- TRUE;
		}
		else {
			cat("Could not install rj extension 'extSource' for '", fname, "'.\n", sep= "");
		}
		
		idx <- .searchExpr(fbody, function(expr) {
				return (length(expr) == 3 && expr[[1]] == "<-"
						&& expr[[2]] == "yy"
						&& length(expr[[3]]) == 2 && expr[[3]][[1]] == "withVisible");
				});
		if (!is.null(idx)) {
			idx.group <- idx[1L:length(idx) - 1];
			idx.insert <- idx[length(idx)];
			c.group <- fbody[[idx.group]];
			tmp <- idx.insert:length(c.group);
			c.group[tmp[-1] + 2] <- c.group[tmp[-1]];
			c.group[tmp[ 1] + 1] <- c.group[tmp[ 1]];
			c.group[[idx.insert]] <- quote(rj:::dbg.checkTB(ei, envir));
			c.group[[idx.insert + 2]] <- quote(rj::dbg.updateTracepoints(envir));
			fbody[[idx.group]] <- c.group;
			changed <- TRUE;
		}
		else {
			cat("Could not install rj extension 'checkTB' for '", fname, "'.\n", sep= "");
		}
		
		if (changed) {
			body(ffun) <- fbody;
			return (patchPackage(fname, ffun, envir= envir));
		}
		return (FALSE);
	}
	injectSource("source", baseEnv);
	injectSrcfile("srcfile", baseEnv);
	injectSrcfile("srcfilecopy", baseEnv);
	
	return (invisible());
}


dbg.checkBreakpoint <- function() {
	if (tracingState(FALSE)) {
		on.exit(tracingState(TRUE));
	}
	
	answer <- .Call("Re_ExecJCommand", "dbg:checkBreakpoint", sys.call(), 0L,
			PACKAGE= "(embedding)" );
	
	if (!is.null(answer)) {
		envir <- sys.frame(-1);
		eval(expr= answer, envir= envir);
	}
}

dbg.checkEB <- function() {
	if (tracingState(FALSE)) {
		on.exit(tracingState(TRUE));
	}
	
	if ("rj" %in% loadedNamespaces()) {
		answer <- .Call("Re_ExecJCommand", "dbg:checkEB", NULL, 0L,
				PACKAGE= "(embedding)" );
		
		if (!is.null(answer)) {
			envir <- sys.frame(-1);
			eval(expr= answer, envir= envir);
		}
	}
}

dbg.checkTB <- function(expr, env) {
	answer <- .Call("Re_ExecJCommand", "dbg:checkTB", list(expr, env), 0L,
			PACKAGE= "(embedding)" );
}


dbg.registerEnv <- function(key, env, objectNames= NULL) {
	.Call("Re_ExecJCommand", "dbg:registerEnv", list(key, env, objectNames), 0L,
			PACKAGE= "(embedding)" );
	return (invisible());
}

dbg.unregisterEnvs <- function(key) {
	.Call("Re_ExecJCommand", "dbg:unregisterEnvs", list(key), 0L,
			PACKAGE= "(embedding)" );
	return (invisible());
}


dbg.updateTracepoints <- function(env, objectNames= NULL) {
	.Call("Re_ExecJCommand", "dbg:updateTracepoints", list(env, objectNames), 0L,
			PACKAGE= "(embedding)" );
	return (invisible());
}


equalsTimestamp <- function(t1, t2) {
	return (t1 == t2
			|| (diff<- abs(round(t1 - t2))) == 0
			|| diff == 3600 );
}

