 #=============================================================================#
 # Copyright (c) 2009, 2019 Stephan Wahlbrink and others.
 # 
 # This program and the accompanying materials are made available under the
 # terms of the Eclipse Public License 2.0 which is available at
 # https://www.eclipse.org/legal/epl-2.0, or the Apache License, Version 2.0
 # which is available at https://www.apache.org/licenses/LICENSE-2.0.
 # 
 # SPDX-License-Identifier: EPL-2.0 OR Apache-2.0
 # 
 # Contributors:
 #     Stephan Wahlbrink <sw@wahlbrink.eu> - initial API and implementation
 #=============================================================================#


## RJ init

#' Environment for configuration
.rj.config <- new.env()
.rj.config$isDebug <- FALSE

#' Environment for temporary R objects
.rj.tmp <- new.env()


#' Initializes the package
.onLoad <- function(libname, pkgname) {
	utilsEnv <- getNamespace("utils")
	assign("help", envir= .rj.originals, value= get("help", envir= utilsEnv))
	assign("help.start", envir= .rj.originals, value= get("help.start", envir= utilsEnv))
	
	options(editor = function(name, file, title) rj::openInEditor(name, file))
	
	apps.initExt()
	
	return (invisible(TRUE));
}

.rj.originals <- new.env()


## Internal utils

.rj.errorHandler <- function(e) {
	if (.rj.config$isDebug) {
		print(e)
	}
}


patchPackage <- function(name, value, envir, ns= TRUE) {
	if (exists(name, envir)) {
		unlockBinding(name, envir)
		on.exit(lockBinding(name, envir), add= TRUE)
		assign(name, value, envir)
	}
	if (ns && getRversion() < "2.15.0") {
		envName <- environmentName(envir)
		if (envName == "base") {
			ns <- "base"
		}
		else if (!is.null(envName) && substring(envName, 1L, 8L) == "package:") {
			ns <- asNamespace(substring(envName, 9L))
		}
		else {
			ns <- NULL
		}
		if (!is.null(ns)) {
			assignInNamespace(name, value, ns= ns)
		}
	}
	return (invisible(TRUE))
}

resolveVisible <- function(result) {
	if (result$visible) {
		return (result$value)
	}
	else {
		return (invisible(result$value))
	}
}
