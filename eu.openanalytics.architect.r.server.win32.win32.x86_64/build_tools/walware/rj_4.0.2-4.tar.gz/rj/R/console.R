 #=============================================================================#
 # Copyright (c) 2010, 2019 Stephan Wahlbrink and others.
 # 
 # This program and the accompanying materials are made available under the
 # terms of the Eclipse Public License 2.0 which is available at
 # https://www.eclipse.org/legal/epl-2.0, or the Apache License, Version 2.0
 # which is available at https://www.apache.org/licenses/LICENSE-2.0.
 # 
 # SPDX-License-Identifier: EPL-2.0 OR Apache-2.0
 # 
 # Contributors:
 #     Stephan Wahlbrink <sw@wahlbrink.eu> - initial API and implementation
 #=============================================================================#


.console.loadHistory <- function(filename= ".Rhistory") {
	if (!is.character(filename) || length(filename) != 1) {
		stop("Illegal argument: filename");
	}
	.client.execCommand("console/loadHistory", list(
					filename= filename ), TRUE);
	return (invisible());
}
.console.saveHistory <- function(filename= ".Rhistory") {
	if (!is.character(filename) || length(filename) != 1) {
		stop("Illegal argument: filename");
	}
	.client.execCommand("console/saveHistory", list(
					filename= filename ), TRUE);
	return (invisible());
}
.console.addtoHistory <- function(line) {
	if (missing(line) || !is.character(line) || length(line) != 1) {
		stop("Illegal argument: line");
	}
	.client.execCommand("console/addtoHistory", list(
					line= line ), FALSE);
	return (invisible());
}

