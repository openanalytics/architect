/*=============================================================================#
 # JavaGD - Java Graphics Device
 # Copyright 2004-2008 Simon Urbanek and others.
 #
 # Licensed under the Apache License, Version 2.0 (the "License");
 # you may not use this file except in compliance with the License.
 # You may obtain a copy of the License at
 # http://www.apache.org/licenses/LICENSE-2.0
 # Unless required by applicable law or agreed to in writing, software
 # distributed under the License is distributed on an "AS IS" BASIS,
 # WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 # See the License for the specific language governing permissions and
 # limitations under the License.
 #=============================================================================*/

public class getsp {
	
    public static void main(String[] args) {
	if (args!=null && args.length>0) {
	    if (args[0].compareTo("-libs")==0) {
		String prefix="-L";
		if (args.length>1) prefix=args[1];
		String lp=System.getProperty("java.library.path");
		// we're not using StringTokenizer in case the JVM is very crude
		int i=0,j,k=0;
		String r=null;
		String pss=System.getProperty("path.separator");
		char ps=':';
		if (pss!=null && pss.length()>0) ps=pss.charAt(0);
		j=lp.length();
		while (i<=j) {
		    if (i==j || lp.charAt(i)==ps) {
			String lib=lp.substring(k,i);
			k=i+1;
			if (lib.compareTo(".")!=0)
			    r=(r==null)?(prefix+lib):(r+" "+prefix+lib);
		    }
		    i++;
		}
		if (r!=null) System.out.println(r);
	    } else
		System.out.println(System.getProperty(args[0]));
	}
    }
}
