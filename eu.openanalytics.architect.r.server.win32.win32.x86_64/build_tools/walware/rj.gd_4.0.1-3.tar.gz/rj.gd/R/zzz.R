 #=============================================================================#
 # Copyright (c) 2009, 2019 Stephan Wahlbrink and others.
 # All rights reserved. This program and the accompanying materials
 # are made available under the terms of the Apache License v2.0
 # which accompanies this distribution, and is available at
 # https://www.apache.org/licenses/LICENSE-2.0
 # 
 # Contributors:
 #     Stephan Wahlbrink <sw@wahlbrink.eu> - initial API and implementation
 #=============================================================================#


.pkg <- new.env()

.onLoad <- function(libname, pkgname) {
	library.dynam("rj.gd", pkgname, libname)
	assign("init", FALSE, env= .pkg)
	assign("cp", as.character(system.file("java", "gd.jar", package="rj.gd")), env= .pkg)
	if (!file.exists(.pkg$cp)) {
		error("gd.jar file for classpath is missing")
	}
	
	deviceIsInteractive("rj.GD")
}

initLib <- function() {
	if (.pkg$init) {
		return(invisible())
	}
	.Call("RJgd_initLib", .pkg$cp, PACKAGE="rj.gd")
	assign("init", FALSE, env= .pkg)
	return(invisible())
}

